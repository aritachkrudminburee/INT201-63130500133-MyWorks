export const add = (...nums) => {
  var sum = nums[0];
  for (let i = 1; i < nums.length; i++) {
    sum += nums[i];
  }
  return sum;
};
export const multiply = (...nums) => {
  var sum = nums[0];
  for (let i = 1; i < nums.length; i++) {
    sum *= nums[i];
  }
  return sum;
};
export const minus = (...nums) => {
  var sum = nums[0];
  for (let i = 1; i < nums.length; i++) {
    sum -= nums[i]; // sum = sum - nums[i];
  }
  return sum;
};
export const divide = (...nums) => {
  var sum = nums[0];
  for (let i = 0; i < nums.length; i++) {
    sum /= nums[i];
  }
  return sum;
};
