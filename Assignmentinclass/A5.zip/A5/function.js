export default function main(...nums) {
  //higher order function
  let data = [];
  let ans = 0;
  for (let i = 1; i <= nums.length; i++) {
    data.push("number"+ i +":" + nums[i-1]);
  }
  //inner is a closure function
  function calculate(operation = "no operation") {
    if (operation != "no operation") ans = operation(...nums);
    data.push("Ans of " + operation.name + " function :" + ans);
    return data;
  }
  return calculate; //return inner function
}
