import {add,divide,multiply,minus} from './calculate.js';
import main from './function.js'
const test1 = main(1, 2, 3);
test1(add)
test1(divide)
test1(minus)
test1(multiply)
console.log(test1());